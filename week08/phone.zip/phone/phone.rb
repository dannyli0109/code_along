class Phone

  def initialize raw_phone_number
    @raw = raw_phone_number
  end


  def number
    result = @raw.gsub(/[^0-9]/,'')
    if result.length > 10
      result_array = result.split('')
      if result_array[0] != "1"
        result = "0000000000"

      else
        result_array.shift
        result = result_array.join
      end
    elsif result.length == 9
      result = "0000000000"
    end
    result
  end


  def area_code
    self.number[0..2]
  end

  def to_s
    # pretty_string = ""
    # pretty_string.concat('(')
    #              .concat(self.number[0..2])
    #              .concat(') ')
    #              .concat(self.number[3..5])
    #              .concat('-')
    #              .concat(self.number[6..9])

    "(#{self.area_code}) #{self.number[3..5]}-#{self.number[6..9]}"
  end




end
